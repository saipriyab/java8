package java8;

public class Employee {
	public int id;
	public String name;
	public String address;
	public float salary;
	public Employee(int id,String name,String address,float salary)
	{
	this.id=id;
	this.name=name;
	this.address=address;
	this.salary=salary;
	}
}
