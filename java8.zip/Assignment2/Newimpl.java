package java8;

public class Newimpl implements Piano,Guitar{
public void play()
{
	System.out.println("Calling from new implementation");
}
}
