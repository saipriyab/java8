package java8;

public class Newimpl1 implements Piano,Guitar{
	public void play()
	{
Piano.super.play();
	}
}
